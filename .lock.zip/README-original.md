# Lockphish v1.0

Lockphish it's the first tool (05/13/2020) for phishing attacks on the lock screen, designed to grab Windows credentials, Android PIN and iPhone Passcode using a https link.

## Author: https://github.com/thelinuxchoice/lockphish
## Twitter: https://twitter.com/linux_choice

![lp](https://user-images.githubusercontent.com/34893261/74437970-e5025000-4e47-11ea-9291-d83afd3fe008.png)

### Features:

#### Lockscreen phishing page for Windows, Android and iPhone
#### Auto detect device
#### Port Forwarding by Ngrok
#### IP Tracker

## Legal disclaimer:

Usage of Lockphish for attacking targets without prior mutual consent is illegal. It's the end user's responsibility to obey all applicable local, state and federal laws. Developers assume no liability and are not responsible for any misuse or damage caused by this program. 

### Usage:
```
git clone https://github.com/thelinuxchoice/lockphish
cd lockphish
bash lockphish.sh
```

### Donate a coffee!
Support the authors:
#### Paypal:
https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=CLKRT5QXXFJY4&source=url
